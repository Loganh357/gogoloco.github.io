Version 1.8.6

Add VRCFury or Modular Avatar to your creator companion to use the auto instal prefab :

	https://vrcfury.com/
	
	https://modular-avatar.nadena.dev

Social Link :

linktr.ee/franada